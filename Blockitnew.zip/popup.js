// popup.js
document.addEventListener('DOMContentLoaded', async () => {
    // Get UI elements with null checks
    const elements = {
        toggle: document.getElementById('adBlockerToggle'),
        youtubeStatus: document.getElementById('youtubeStatus'),
        spotifyStatus: document.getElementById('spotifyStatus'),
        iplStatus: document.getElementById('iplStatus'),
        statusIcon: document.querySelector('.status-icon'),
        statusText: document.querySelector('.status-text'),
        totalBlocked: document.getElementById('totalBlocked'),
        listsActive: document.getElementById('listsActive'),
        lastUpdate: document.getElementById('lastUpdate'),
        updateButton: document.getElementById('updateFilters')
    };

    // Verify all elements exist
    for (const [key, element] of Object.entries(elements)) {
        if (!element) {
            console.error(`Required element not found: ${key}`);
        }
    }

    // Format functions
    const formatNumber = (num) => {
        if (!num) return '0';
        if (num >= 1000000) return `${(num / 1000000).toFixed(1)}M`;
        if (num >= 1000) return `${(num / 1000).toFixed(1)}K`;
        return num.toString();
    };

    const formatDate = (timestamp) => {
        if (!timestamp) return 'Never';
        const date = new Date(timestamp);
        const now = new Date();
        const diff = now - date;

        if (diff < 60000) return 'Just now';
        if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
        if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
        return date.toLocaleDateString();
    };

    // Update UI function
    const updateUI = async () => {
        try {
            const stats = await chrome.storage.local.get([
                'adBlockerEnabled',
                'totalBlocked',
                'lastFilterUpdate',
                'totalRules',
                'lastFilterError',
                'lastFilterErrorTime'
            ]);

            // Update toggle state
            if (elements.toggle) {
                elements.toggle.checked = stats.adBlockerEnabled !== false;
            }

            // Update blocking stats
            if (elements.totalBlocked) {
                elements.totalBlocked.textContent = formatNumber(stats.totalBlocked);
            }

            // Update lists count
            if (elements.listsActive) {
                elements.listsActive.textContent = '3'; // EasyList, EasyPrivacy, Peter Lowe's
            }

            // Update last update time
            if (elements.lastUpdate) {
                elements.lastUpdate.textContent = formatDate(stats.lastFilterUpdate);
            }

            // Update status indicators
            const isEnabled = stats.adBlockerEnabled !== false;
            const status = isEnabled ? 'Active' : 'Paused';
            const color = isEnabled ? '#4caf50' : '#666';

            ['youtubeStatus', 'spotifyStatus', 'iplStatus'].forEach(id => {
                if (elements[id]) {
                    elements[id].textContent = status;
                    elements[id].style.color = color;
                }
            });

            if (elements.statusIcon) {
                elements.statusIcon.style.backgroundColor = isEnabled ? '#4caf50' : '#ccc';
            }

            if (elements.statusText) {
                elements.statusText.textContent = isEnabled ? 'Protected' : 'Paused';
                elements.statusText.style.color = color;

                // Show total blocked if available
                if (isEnabled && stats.totalBlocked) {
                    elements.statusText.textContent = `Protected (${formatNumber(stats.totalBlocked)} blocked)`;
                }
            }

            // Show error if exists
            if (stats.lastFilterError && Date.now() - stats.lastFilterErrorTime < 5000) {
                console.warn('Last filter update error:', stats.lastFilterError);
            }

        } catch (error) {
            console.error('Error updating UI:', error);
        }
    };

    // Initialize UI
    await updateUI();

    // Add event listeners
    if (elements.toggle) {
        elements.toggle.addEventListener('change', async () => {
            const enabled = elements.toggle.checked;
            await chrome.storage.local.set({ adBlockerEnabled: enabled });
            await updateUI();

            // Notify tabs
            chrome.tabs.query({}, (tabs) => {
                tabs.forEach((tab) => {
                    if (tab.url?.includes('youtube.com') || 
                        tab.url?.includes('spotify.com') || 
                        tab.url?.includes('hotstar.com') ||
                        tab.url?.includes('jiocinema.com')) {
                        chrome.tabs.sendMessage(tab.id, {
                            type: 'BLOCKIT_TOGGLE',
                            enabled: enabled
                        }).catch(() => {/* Ignore errors for inactive tabs */});
                    }
                });
            });
        });
    }

    if (elements.updateButton) {
        elements.updateButton.addEventListener('click', async () => {
            try {
                elements.updateButton.disabled = true;
                elements.updateButton.textContent = 'Updating...';
                
                await chrome.runtime.sendMessage({ action: 'updateRules' });
                
                elements.updateButton.textContent = 'Updated!';
                setTimeout(() => {
                    elements.updateButton.disabled = false;
                    elements.updateButton.textContent = 'Update Now';
                }, 2000);
                
                await updateUI();
            } catch (error) {
                console.error('Error updating rules:', error);
                elements.updateButton.textContent = 'Error!';
                setTimeout(() => {
                    elements.updateButton.disabled = false;
                    elements.updateButton.textContent = 'Update Now';
                }, 2000);
            }
        });
    }

    // Listen for updates from background script
    chrome.runtime.onMessage.addListener((message) => {
        if (message.action === 'statsUpdated') {
            updateUI();
        }
    });
}); 